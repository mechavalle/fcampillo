<style type="text/css">

.social 
	{
	display: block;
	position: fixed; 
	left: 0px; 
	top: 110px;
	z-index: 2000;
	font-size: smaller;
	list-style: none;
	background-color: #88ccca36;
	text-align: center;
	padding-top: 0.5em;
    padding-bottom: 0.5em;
    padding-left: 0.5em;
    padding-right: 0.5em;
    border-bottom-right-radius: 15px;
    border-top-right-radius: 15px;
	} 

.social a:hover
	{
	font-size: small;	
	}	

</style>

<div class="social sc_socials sc_socials_type_icons sc_socials_shape_round">
    <li  style="margin-bottom: 6px;"><a href="https://www.facebook.com/fercampillowp" target="_blank" class="social_ico"><span class="icon-facebook" style="font-size: xx-large;"></span></a></li>
    <li  style="margin-bottom: 6px;"><a href="https://www.pinterest.com/fercampillowp" target="_blank" class="social_ico"><span class="fa fa-pinterest-p" style="font-size: xx-large; vertical-align: middle;"></span></a></li>
    <li  style="margin-bottom: 6px;"><a href="https://www.instagram.com/fercampillowp" target="_blank" class="social_ico"><span class="icon-instagramm" style="font-size: xx-large;"></span></a></li>
</div>