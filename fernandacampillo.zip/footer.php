
<div class="footer_wrap_inner widget_area_inner">
    <div class="content_wrap">
        <aside id="lovestory_widget_socials-2" class="widget_number_1 widget widget_socials">
            <div class="widget_inner">
                <div class="row">
                    <div class="column-1_3">
                        <div class="txtfooter" style="text-align: left;">
                            <p style="font-size: 13.7px;">
                                <a style="font-size: 13.7px;">CDMX</a><br>  
                                Boulevard Manuel Ávila Camacho 24,<br>
                                Col. Lomas de Chapultepec,<br>
                                Del. Miguel Hidalgo, C.P. 11000<br>
                            </p>
                            <p style="font-size: 13.7px;">    
                                <a style="font-size: 13.7px;">RIVIERA MAYA</a><br>
                                Azuna Corporate Center piso 11<br>
                                Av. Sayil esquina Av. Savignac<br>
                            </p>
                            <p style="font-size: 13.7px;">
                                <a href="mailto:info@fernandacampillo.com">info@fernandacampillo.com</a>
                                <br>
                                <a href="callto:+5552140418">Tel. 55 5214 0418</a>
                            </p>
                        </div> 
                    </div> 
                    <div class="column-1_3" style="text-align: center !important;">  
                        <div class="logo">
                            <img src="images/logotipo.png" class="logo_main" style="padding-bottom: 55px;"></a>  
                        </div>
                        <div class="copyright_text" style="font-size: 13.7px;">
                            <font style="color: #88ccca;">&copy; Copyright FERNANDA CAMPILLO 2018 |</font><a target="" href="aviso.php" style="color: #737373;"> AVISO DE PRIVACIDAD</a>
                        </div>
                    </div> 
                    <div class="column-1_3" style="text-align: center !important;">
                        <div class="logo" style="letter-spacing: 20px;">
                            <div class="row">
                                <img src="images/badge-gold_es_MX@2x.jpg" class="logo_main">
                                <img src="images/2.png" class="logo_main">
                                <img src="images/unnamed.jpeg" class="logo_main">
                                <img src="images/seal_bodas_es_MX.png" class="logo_main" style=" margin-top: 20px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </aside>
    </div>
</div>
