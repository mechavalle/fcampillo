<div class="top_panel_middle">
    <div class="columns_wrap columns_fluid">
        <div class="column-1_6 contact_field contact_cart">
            <a href="mailto:info@fernandacampillo.com">
                <span class="contact_icon icon-icon6"></span> 
                <span class="contact_cart_totals"><span class="cart_items" style="font-size: 15px;"> &nbsp; info@fernandacampillo.com</span></span>
            </a>
        </div>
        <div class="column-1_6 contact_field contact_phone">
            <a href="callto:+5552140418"> 
                <span class="contact_icon icon-phone"></span> 
                <span class="contact_label contact_phone" style="font-size: 15px;"> &nbsp; 55 5214 0418</span>
            </a>
        </div>
    </div>
</div>
